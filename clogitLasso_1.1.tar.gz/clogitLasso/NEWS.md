1.1.0 (2018-06-20)
  - Speedup the case 1:M matching
  - Fix bug in "number of folds used in cross validation"

1.0.1 (2016-09-26)
  - initial CRAN release